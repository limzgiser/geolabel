import { RouteRoutingModule } from './routes.routing';
import { NgModule } from '@angular/core';

@NgModule({
  imports: [
    RouteRoutingModule
  ],
  declarations: []
})
export class LayoutRoutesModule { }
