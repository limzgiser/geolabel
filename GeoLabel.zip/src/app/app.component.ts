import { Component } from '@angular/core';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: '#angular9 app-root',
  template: `<router-outlet></router-outlet>`,
  styles: [``]
})
export class AppComponent {

}
