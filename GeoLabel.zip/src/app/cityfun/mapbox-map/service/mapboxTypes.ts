export type cursorType =
  | 'default'
  | 'pointer'
  | 'crosshair'
  | 'text'
  | 'move'
  | 'grab';
